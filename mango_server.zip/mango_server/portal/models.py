from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    stock = models.IntegerField()
    image = models.ImageField(upload_to='products/')
    is_package = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    def total_price(self):
        return self.product.price * self.quantity

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"


class Order(models.Model):
    # This is correct from our last fix for guest checkout
    customer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    # ADDED fields for phone and email
    email = models.EmailField(null=True, blank=True)
    phone = models.CharField(max_length=20)
    
    address = models.TextField()
    city = models.CharField(max_length=100, null=True, blank=True)
    zip_code = models.CharField(max_length=20, null=True, blank=True)
    
    delivery_method = models.CharField(max_length=100)
    delivery_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # This field will store the price for a PACKAGE order, or 0 for a CART order
    package_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # ADDED fields for payment
    payment_method = models.CharField(max_length=50, default='cash')
    transaction_id = models.CharField(max_length=100, null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def get_subtotal(self):
        # This calculates the subtotal ONLY for cart-based orders
        return sum(item.price * item.quantity for item in self.items.all())

    def get_grand_total(self):
        # This method is now smart
        if self.package_price > 0:
            # It's a package order
            return self.package_price + self.delivery_charge
        else:
            # It's a cart order
            return self.get_subtotal() + self.delivery_charge

    def __str__(self):
        return f"Order #{self.id} - {self.first_name} {self.last_name}"


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order, on_delete=models.CASCADE, related_name='items')
    product_name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.quantity} x {self.product_name}"
    
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    otp_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"Profile of {self.user.username}"

@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    else:
        instance.profile.save()
    

