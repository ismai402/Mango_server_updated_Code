from decimal import Decimal
from django.shortcuts import redirect, get_object_or_404
from django.urls import reverse
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST, require_GET
from django.contrib import messages
from django.utils.crypto import get_random_string
from django.utils import timezone
from django.core.mail import send_mail
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.conf import settings
from django.contrib.auth.decorators import user_passes_test
from datetime import timedelta
import datetime
from .forms import ProductForm
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Product, CartItem, Order, OrderItem, Profile

User = get_user_model()

# @login_required(login_url='login')
def home(request):
    products = Product.objects.all()[:4]  # get first 4 products for featured
    return render(request, 'home.html', {'products': products})


# @login_required(login_url='login')
def about(request):
    return render(request, 'about.html')


# @login_required(login_url='login')
def products(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})


def user_login(request):
    if request.method == 'POST':
        uname = request.POST['username']
        pwd = request.POST['password']
        user = authenticate(request, username=uname, password=pwd)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')


def user_register(request):
    if request.method == 'POST':
        uname = request.POST['username']
        email = request.POST['email']
        pwd = request.POST['password']
        cpwd = request.POST['confirm_password']

        if pwd != cpwd:
            messages.error(request, 'Passwords do not match!')
        elif User.objects.filter(username=uname).exists():
            messages.error(request, 'Username already exists!')
        else:
            user = User.objects.create_user(
                username=uname, email=email, password=pwd)
            user.save()
            messages.success(request, 'Account created successfully!')
            return redirect('login')
    return render(request, 'register.html')


def user_logout(request):
    logout(request)
    return redirect('login')


def product_list(request):
    query = request.GET.get("q", "")
    products = Product.objects.all()

    if query:
        products = products.filter(Q(name__icontains=query))

    paginator = Paginator(products, 6)  # 6 products per page
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    return render(request, 'products.html', {
        'products': page_obj,
        'paginator': paginator,
        'page_obj': page_obj,
        'is_paginated': page_obj.has_other_pages(),
    })


# views.py
# def product_detail(request, id):
#     product = get_object_or_404(Product, id=id)
#     cart_item = CartItem.objects.filter(
#         product=product, user=request.user).first()
#     current_quantity = cart_item.quantity if cart_item else 1

#     return render(request, 'product_detail.html', {
#         'product': product,
#         'current_quantity': current_quantity
#     })

def product_detail(request, id):
    product = get_object_or_404(Product, id=id)

    cart = request.session.get('cart', {})
    current_quantity = cart.get(str(product.id), 1)

    return render(request, 'product_detail.html', {
        'product': product,
        'current_quantity': current_quantity
    })


# def add_to_cart(request, product_id):
#     product = get_object_or_404(Product, id=product_id)
#     requested_quantity = int(request.POST.get('quantity', 1))

#     if requested_quantity < 1:
#         requested_quantity = 1

#     cart = request.session.get('cart', {})
#     current_in_cart = cart.get(str(product_id), 0)

#     remaining_stock = product.stock - current_in_cart

#     if remaining_stock <= 0:
#         messages.error(
#             request, f"{product.name} already in cart with max available stock!")
#         return redirect('product_detail', id=product.id)

#     # Limit to remaining stock
#     final_quantity_to_add = min(requested_quantity, remaining_stock)
#     cart[str(product_id)] = current_in_cart + final_quantity_to_add
#     request.session['cart'] = cart

#     if final_quantity_to_add < requested_quantity:
#         messages.warning(
#             request, f"Only {final_quantity_to_add} more of {product.name} added. Stock limit reached."
#         )
#     else:
#         messages.success(
#             request, f"{product.name} added to cart (Quantity: {final_quantity_to_add})!")

#     return redirect('product_detail', id=product.id)

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    requested_quantity = int(request.POST.get('quantity', 1))

    if requested_quantity < 1:
        requested_quantity = 1

    cart = request.session.get('cart', {})
    current_in_cart = cart.get(str(product_id), 0)

    remaining_stock = product.stock - current_in_cart

    if remaining_stock <= 0:
        messages.error(
            request, f"{product.name} already in cart with max available stock!")
        return redirect('product_detail', id=product.id)

    # Limit to remaining stock
    final_quantity_to_add = min(requested_quantity, remaining_stock)
    cart[str(product_id)] = current_in_cart + final_quantity_to_add
    request.session['cart'] = cart
    request.session.modified = True

    if final_quantity_to_add < requested_quantity:
        messages.warning(
            request, f"Only {final_quantity_to_add} more of {product.name} added. Stock limit reached."
        )
    else:
        messages.success(
            request, f"{product.name} added to cart (Quantity: {final_quantity_to_add})!")

    return redirect('product_detail', id=product.id)


# @login_required
def cart_view(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0

    for product_id, quantity in cart.items():
        try:
            product = Product.objects.get(id=product_id)
            item_total = product.price * quantity
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'subtotal': item_total
            })
            total_price += item_total
        except Product.DoesNotExist:
            continue

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })

def increase_quantity(request, product_id):
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        product_id_str = str(product_id)

        if product_id_str in cart:
            cart[product_id_str] += 1
        else:
            cart[product_id_str] = 1

        request.session['cart'] = cart
    return redirect('cart')


def decrease_quantity(request, product_id):
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        product_id_str = str(product_id)

        if product_id_str in cart:
            if cart[product_id_str] > 1:
                cart[product_id_str] -= 1
            else:
                # If only 1 item left, remove it completely
                del cart[product_id_str]

        request.session['cart'] = cart
    return redirect('cart')


def remove_from_cart(request, product_id):
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        product_id_str = str(product_id)

        if product_id_str in cart:
            del cart[product_id_str]
            request.session['cart'] = cart

    return redirect('cart')


def checkout_view(request):
    cart = request.session.get('cart', {})
    
    # This logic correctly handles both cases without an error
    if cart:
        # --- CART CHECKOUT FLOW ---
        # The cart has items, so prepare them for display.
        cart_items = []
        subtotal = Decimal('0.00')
        for product_id, quantity in cart.items():
            try:
                product = Product.objects.get(id=product_id)
                item_total = product.price * quantity
                cart_items.append({
                    'product': product,
                    'quantity': quantity,
                    'subtotal': item_total
                })
                subtotal += item_total
            except Product.DoesNotExist:
                continue
        
        context = {
            'is_cart_checkout': True,
            'cart_items': cart_items,
            'subtotal': subtotal,
        }
    else:
        # --- PACKAGE CHECKOUT FLOW ---
        # The cart is empty, so we just set the flag for the package UI.
        context = {
            'is_cart_checkout': False,
        }
        
    return render(request, 'checkout.html', context)



def start_package_checkout(request):
    # This view's only job is to clear the cart and start the package flow
    if 'cart' in request.session:
        del request.session['cart']
        request.session.modified = True
    return redirect('checkout')


# @require_POST
# def process_checkout(request):
#     first_name = request.POST.get('first_name')
#     last_name = request.POST.get('last_name')
#     address = request.POST.get('address')
#     city = request.POST.get('city')
#     zip_code = request.POST.get('zip_code')

#     # Create order
#     order = Order.objects.create(
#         customer=request.user,
#         first_name=first_name,
#         last_name=last_name,
#         address=address,
#         city=city,
#         zip_code=zip_code
#     )

#     # Save cart items as OrderItems
#     cart = request.session.get('cart', {})
#     for product_id, quantity in cart.items():
#         try:
#             product = Product.objects.get(id=product_id)
#         except Product.DoesNotExist:
#             continue  # skip invalid products

#         OrderItem.objects.create(
#             order=order,
#             product=product,
#             price=product.price,
#             quantity=quantity
#         )

#     # Clear cart
#     if 'cart' in request.session:
#         del request.session['cart']
#     request.session.modified = True

#     return render(request, 'greatful.html', {'name': first_name, 'order': order})


@require_POST
def process_checkout(request):
    # Get common form data
    first_name = request.POST.get('first_name')
    last_name = request.POST.get('last_name')
    email = request.POST.get('email')
    phone = request.POST.get('phone')
    address = request.POST.get('address')
    city = request.POST.get('city')
    zip_code = request.POST.get('zip_code')
    delivery_method = request.POST.get('delivery_method')
    payment_method = request.POST.get('payment_method')
    transaction_id = request.POST.get('transaction_id')
    # This hidden field is the key to our logic
    checkout_mode = request.POST.get('checkout_mode')

    # Determine customer (for guest or logged-in users)
    customer_instance = None
    if request.user.is_authenticated:
        customer_instance = request.user

    # Always calculate delivery charge on the server for security
    delivery_charge = Decimal('150.00') if delivery_method == 'home' else Decimal('0.00')
    
    # Create the base order object
    order = Order.objects.create(
        customer=customer_instance,
        first_name=first_name,
        last_name=last_name,
        email=email,
        phone=phone,
        address=address,
        city=city,
        zip_code=zip_code,
        delivery_method=delivery_method,
        payment_method=payment_method,
        transaction_id=transaction_id,
        delivery_charge=delivery_charge
    )

    # Now, handle the specific logic based on the checkout mode
    if checkout_mode == 'cart':
        cart = request.session.get('cart', {})
        if not cart:
            messages.error(request, "Your cart was empty. The order could not be placed.")
            order.delete() # Clean up the empty order we just created
            return redirect('cart')

        for product_id, quantity in cart.items():
            try:
                product = Product.objects.get(id=product_id)
                OrderItem.objects.create(
                    order=order,
                    product_name=product.name,
                    price=product.price,
                    quantity=quantity
                )
                product.stock -= quantity
                product.save()
            except (Product.DoesNotExist, ValueError):
                continue
        
        request.session.pop('cart', None) # Clear the cart after a successful order

    elif checkout_mode == 'package':
        package_value = request.POST.get('package_weight')
        # Use a server-side dictionary for security, ignoring client-side prices
        package_prices = {
            '12': Decimal('600.00'),
            '24': Decimal('1200.00'),
            '36': Decimal('1800.00'),
        }
        package_price = package_prices.get(package_value, Decimal('0.00'))
        
        if package_price == Decimal('0.00'):
            messages.error(request, "An invalid package was selected. Please try again.")
            order.delete() # Clean up
            return redirect('checkout')

        order.package_price = package_price
        # No OrderItems are created for package orders
        
    order.save()
    request.session.modified = True

    return render(request, 'greatful.html', {'name': first_name, 'order': order})


@staff_member_required
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form})


@staff_member_required
def edit_products(request):
    products = Product.objects.all()
    return render(request, 'edit_product_list.html', {'products': products})


@staff_member_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, "Product updated successfully!")
            return redirect('edit_products')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})


@staff_member_required
def delete_products(request):
    products = Product.objects.all()
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        product = get_object_or_404(Product, id=product_id)
        product.delete()
        messages.success(request, "Product deleted successfully!")
        return redirect('delete_products')
    return render(request, 'delete_product.html', {'products': products})


@staff_member_required
def order_list(request):
    orders = Order.objects.all().order_by('-created_at')

    for order in orders:
        order.is_package = order.package_price > 0

        if order.is_package:
            order.order_items_total = order.package_price
        else:
            order.order_items_total = sum(
                item.price * item.quantity for item in order.items.all())
            
        order.total_price_with_delivery = order.order_items_total + order.delivery_charge

    return render(request, 'order_list.html', {'orders': orders})


# views.py


# @login_required
# def update_cart_quantity(request, product_id):
#     if request.method == 'POST':
#         action = request.POST.get('action')  # 'increase' or 'decrease'

#         cart = request.session.get('cart', {})

#         current_qty = cart.get(str(product_id), 1)

#         if action == 'increase':
#             current_qty += 1
#             cart[str(product_id)] = current_qty
#         elif action == 'decrease':
#             if current_qty > 1:
#                 current_qty -= 1
#                 cart[str(product_id)] = current_qty
#             else:
#                 cart.pop(str(product_id), None)

#         request.session['cart'] = cart
#         request.session.modified = True

#     return redirect('product_detail', id=product_id)


# @login_required
# def update_cart_quantity(request, product_id):
#     if request.method == 'POST':
#         try:
#             product = get_object_or_404(Product, id=product_id)
#             action = request.POST.get('action', '').lower()
#             cart = request.session.get('cart', {})
#             product_key = str(product_id)

#             current_qty = cart.get(product_key, 1)

#             if action == 'increase':
#                 # Ensure we don't exceed available stock
#                 if current_qty < product.stock:
#                     current_qty += 1
#                     cart[product_key] = current_qty
#                     messages.success(
#                         request, f"Quantity increased for {product.name}")
#                 else:
#                     messages.warning(
#                         request, f"Cannot exceed available stock ({product.stock})")
#             elif action == 'decrease':
#                 if current_qty > 1:
#                     current_qty -= 1
#                     cart[product_key] = current_qty
#                     messages.success(
#                         request, f"Quantity decreased for {product.name}")
#                 else:
#                     # Remove item if quantity would go to 0
#                     cart.pop(product_key, None)
#                     messages.info(request, f"{product.name} removed from cart")
#             else:
#                 messages.error(request, "Invalid action requested")

#             request.session['cart'] = cart
#             request.session.modified = True

#         except Exception as e:
#             messages.error(
#                 request, "An error occurred while updating your cart")
#             # Log the error for debugging
#             print(f"Error updating cart: {str(e)}")

#     # Redirect back to either the product detail or cart page based on referrer
#     referer = request.META.get('HTTP_REFERER')
#     if referer and 'cart' in referer:
#         return redirect('cart')
#     return redirect('product_detail', id=product_id)



def update_cart_quantity(request, product_id):
    if request.method == 'POST':
        try:
            product = get_object_or_404(Product, id=product_id)
            action = request.POST.get('action')

            cart = request.session.get('cart', {})
            product_key = str(product_id)
            current_qty = cart.get(product_key, 1)

            if action == 'increase':
                current_qty += 1
            elif action == 'decrease':
                current_qty = max(1, current_qty - 1)  # Never go below 1

            cart[product_key] = current_qty
            request.session['cart'] = cart
            request.session.modified = True

        except Exception as e:
            messages.error(request, "Couldn't update quantity")
            print(f"Error: {e}")

    return redirect('product_detail', id=product_id)


# Helper
def is_admin(user):
    return user.is_authenticated and user.is_staff and user.profile.otp_verified

# Admin login
def admin_login_view(request):
    if request.method == 'POST':
        email_or_username = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, username=email_or_username, password=password)
        if user and user.is_staff:
            request.session['admin_user_id'] = user.id
            otp = get_random_string(length=6, allowed_chars='0123456789')
            request.session['admin_otp'] = otp
            request.session['otp_expiry'] = (timezone.now() + timedelta(minutes=2)).isoformat()
            send_mail("Mango Lover Admin OTP", f"Your OTP code is: {otp}", settings.EMAIL_HOST_USER, [user.email])
            return redirect('admin_otp')
        messages.error(request, 'Invalid credentials or not a staff user.')
    return render(request, 'admin_login.html')

# OTP Page
def admin_otp_view(request):
    user_id = request.session.get('admin_user_id')
    otp_expiry = request.session.get('otp_expiry')
    if not user_id or not otp_expiry:
        return redirect('admin_login')

    user = User.objects.get(id=user_id)
    # Ensure profile exists
    if not hasattr(user, 'profile'):
        Profile.objects.create(user=user)
    otp_expiry_time = datetime.datetime.fromisoformat(otp_expiry)

    if request.method == 'POST':
        input_otp = request.POST.get('otp')
        if timezone.now() > otp_expiry_time:
            messages.error(request, 'OTP expired.')
            return redirect('admin_login')
        if input_otp == request.session.get('admin_otp'):
            user.profile.otp_verified = True
            user.profile.save()
            login(request, user)
            return redirect('admin_dashboard')
        else:
            messages.error(request, 'Invalid OTP.')
            return redirect('admin_login')

    return render(request, 'admin_otp.html', {'expires_in': int((otp_expiry_time - timezone.now()).total_seconds())})

@require_GET
def admin_resend_otp(request):
    user_id = request.session.get('admin_user_id')
    if not user_id:
        return redirect('admin_login')

    user = User.objects.get(id=user_id)
    otp = get_random_string(length=6, allowed_chars='0123456789')
    request.session['admin_otp'] = otp
    request.session['otp_expiry'] = (timezone.now() + timedelta(minutes=2)).isoformat()

    send_mail(
        "Mango Lover Admin OTP - Resent",
        f"Your new OTP is: {otp}",
        settings.EMAIL_HOST_USER,
        [user.email]
    )
    messages.success(request, "OTP resent successfully. Please check your email.")
    return redirect('admin_otp')


@user_passes_test(is_admin)
def admin_dashboard(request):
    orders = Order.objects.all().order_by('-created_at')
    return render(request, 'admin_dashboard.html', {'orders': orders})


# Forgot Password
def admin_forgot_password(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        user = User.objects.filter(email=email, is_staff=True).first()
        if user:
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            link = request.build_absolute_uri(reverse('admin_password_reset_confirm', args=[uid, token]))
            send_mail('Reset your Mango Lover Admin Password',
                      f'Click the link below to reset:\n{link}',
                      settings.EMAIL_HOST_USER,
                      [user.email])
            messages.success(request, 'Reset link sent to email.')
            return redirect('admin_login')
        else:
            messages.error(request, 'No admin account with that email.')
    return render(request, 'admin_forgot_password.html')

# Password Reset Confirm
def admin_password_reset_confirm(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid, is_staff=True)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user and default_token_generator.check_token(user, token):
        if request.method == 'POST':
            new_password = request.POST['new_password']
            user.set_password(new_password)
            user.save()
            messages.success(request, 'Password reset successful.')
            return redirect('admin_login')
        return render(request, 'admin_reset_confirm.html')
    else:
        messages.error(request, 'Invalid or expired link.')
        return redirect('admin_login')

# Admin logout
@user_passes_test(is_admin)
def admin_logout(request):
    logout(request)
    return render(request, 'logout_success.html')

# views.py
# from django.shortcuts import redirect, get_object_or_404
# from .models import Product, CartItem  # adjust as needed

# def update_cart_quantity(request, id):
#     if request.method == "POST":
#         product = get_object_or_404(Product, id=id)
#         quantity = int(request.POST.get("quantity", 1))

#         # Get cart item
#         cart_item = CartItem.objects.filter(product=product, user=request.user).first()
#         if cart_item:
#             cart_item.quantity = quantity
#             cart_item.save()
#         else:
#             # Optional: Create if not found
#             CartItem.objects.create(product=product, user=request.user, quantity=quantity)

#         return redirect('product_detail', id=id)

def faq_view(request):
    return render(request, 'faq.html')


def contact_view(request):
    return render(request, 'contact.html')

def shipping_info_view(request):
    return render(request, 'shipping_info.html')

def why_choose_us(request):
    return render(request, 'why_choose_us.html')

def refund_policy_view(request):
    return render(request, 'refund_policy.html')